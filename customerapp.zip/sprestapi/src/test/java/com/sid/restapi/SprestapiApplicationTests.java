package com.sid.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

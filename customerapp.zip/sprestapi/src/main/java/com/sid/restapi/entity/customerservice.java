package com.sid.restapi.entity;
import com.sid.restapi.*;
import com.sid.restapi.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class customerservice {

    @Autowired
    private CustomerRepository customerRepository;

    public customer addcustomer(customer customer) {
        return CustomerRepository.save(customer);
    }

    public List<customer> getAllcustomers() {
        return CustomerRepository.findAll();
    }

    public customer updateCustomer(int custid, int phno) {
        customer customer = CustomerRepository.findById(custid).orElse(null);
        if (customer != null) {
            customer.setPhno(phno);
            customerRepository.save(customer);
        }
        return customer;
    }

    public void deleteCustomer(int custid) {
        CustomerRepository.deleteById(custid);
    }
}

public class customerservice {

}

package com.sid.restapi;

import com.sid.restapi.*;
import com.sid.restapi.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private customerservice customerService;

    @PostMapping("/add")
    public customer addCustomer(@RequestBody customer customer) {
        return customerservice.addCustomer(customer);
    }

    @GetMapping("/all")
    public List<Customer> getAllCustomers() {
        return customerservice.getAllCustomers();
    }

    @PutMapping("/update/{custid}")
    public customer updatecustomer(@PathVariable int custid, @RequestParam int phno) {
        return customerservice.updatecustomer(custid, phno);
    }

    @DeleteMapping("/delete/{custid}")
    public void deletecustomer(@PathVariable int custid) {
        customerService.deleteCustomer(custid);
    }
}

public class CustomerController {

}

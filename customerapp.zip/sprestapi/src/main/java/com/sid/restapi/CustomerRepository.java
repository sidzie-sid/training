package com.sid.restapi;

import com.sid.restapi.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<customer, int> {
}
public class CustomerRepository {

}

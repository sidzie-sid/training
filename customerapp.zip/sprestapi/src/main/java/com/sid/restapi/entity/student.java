package com.sid.restapi.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
@Entity
@Table(name="student") 
public class student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int rollno;
	@Column(name="student_name")
	private String name;
	@Column(name="student_branch")
	private String branch;
	@Column(name="student_percentage")
	private float percentage;
	public student()
	{
		
	}
	
	public student(String name, String branch, float percentage) {
		super();
		this.name = name;
		this.branch = branch;
		this.percentage = percentage;
	}

	@Override
	public String toString() {
		return "student [rollno=" + rollno + ", name=" + name + ", branch=" + branch + ", percentage=" + percentage
				+ "]";
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

}

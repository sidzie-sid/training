package com.sid.restapi.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
@Entity
@Table(name="customer") 
public class customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int custid;
	@Column(name="customer_name")
	private String name;
	@Column(name="customer_phno")
	private int phno;
	
	public customer()
	{
		
	}
	
	public customer(String name, int phno) {
		super();
		this.name = name;
		this.phno = phno;
		
	}

	@Override
	public String toString() {
		return "customer [custid=" + custid + ", name=" + name + " phno=" + phno + "]";
	}
	public int getcustid() {
		return custid;
	}
	public void setcustid(int custid) {
		this.custid = custid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getphno() {
		return phno;
	}
	public void setBranch(int phno) {
		this.phno = phno;
	}
	

}

// class customer {}
